USE metro_cdmx;

-- Insertar las líneas del metro
INSERT INTO `lines` (name, color) VALUES
("Línea 1", "Rosa"),
("Línea 2", "Azul"),
("Línea 3", "Verde olivo"),
("Línea 4", "Cian"),
("Línea 5", "Amarillo"),
("Línea 6", "Rojo"),
("Línea 7", "Naranja"),
("Línea 8", "Verder"),
("Línea 9", "Café"),
("Línea A", "Morado"),
("Línea B", "Verde y gris"),
("Línea 12", "Oro");