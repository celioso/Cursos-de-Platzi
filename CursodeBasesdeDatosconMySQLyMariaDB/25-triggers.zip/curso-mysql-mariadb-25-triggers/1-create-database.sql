-- Crear la base de datos

CREATE DATABASE metro_cdmx;