USE metro_cdmx;

DELETE FROM `stations`
WHERE id = 164;

DELETE FROM `stations`
WHERE id = 165;

DELETE FROM `stations`
WHERE name = "Benito Cárdenas";