USE metro_cdmx;

DROP TABLE `stations_delete`;